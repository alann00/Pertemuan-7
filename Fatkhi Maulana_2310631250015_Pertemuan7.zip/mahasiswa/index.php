<?php
include '../koneksi.php';
$result = mysqli_query($conn, "SELECT * FROM mahasiswa");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Kuliah</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #eef2f3;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            padding: 20px;
            color: #2c3e50;
        }
        .menu {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            padding: 30px;
        }
        .menu a {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            font-size: 18px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background 0.3s, transform 0.3s;
        }
        .menu a:hover {
            background-color: #2980b9;
            transform: translateY(-3px);
        }
    </style>
</head>
<h2>Data Mahasiswa</h2>
<a href="create.php">+ Tambah Mahasiswa</a>
<table border="1" cellpadding="8">
  <tr>
    <th>NPM</th>
    <th>Nama</th>
    <th>Jurusan</th>
    <th>Alamat</th>
    <th>Aksi</th>
  </tr>

  <?php while($row = mysqli_fetch_assoc($result)) { ?>
  <tr>
    <td><?= $row['NPM'] ?></td>
    <td><?= $row['Nama'] ?></td>
    <td><?= $row['Jurusan'] ?></td>
    <td><?= $row['Alamat'] ?></td>
    <td>
      <a href="edit.php?npm=<?= $row['NPM'] ?>">Edit</a> |
      <a href="delete.php?npm=<?= $row['NPM'] ?>" onclick="return confirm('Yakin?')">Hapus</a>
    </td>
  </tr>
  <?php } ?>
</table>