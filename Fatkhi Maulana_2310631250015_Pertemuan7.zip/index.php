<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sistem KRS</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f0f2f5;
      margin: 0;
      padding: 20px;
      color: #333;
    }
    header {
      text-align: center;
      margin-bottom: 30px;
    }
    header h2 {
      color: #2c3e50;
      margin-bottom: 10px;
    }
    nav {
      text-align: center;
      margin-bottom: 30px;
    }
    nav a {
      background-color: #3498db;
      color: white;
      padding: 12px 20px;
      margin: 0 10px;
      text-decoration: none;
      border-radius: 6px;
      font-size: 16px;
      transition: background 0.3s, transform 0.2s;
    }
    nav a:hover {
      background-color: #2980b9;
      transform: translateY(-2px);
    }
    main {
      background: white;
      padding: 30px;
      max-width: 700px;
      margin: auto;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    main h3 {
      margin-top: 0;
      color: #34495e;
    }
    ul {
      margin-top: 15px;
      padding-left: 20px;
    }
    ul li {
      margin-bottom: 10px;
    }
    footer {
      text-align: center;
      margin-top: 40px;
      font-size: 14px;
      color: #7f8c8d;
    }
  </style>
</head>
<body>


<h2>📝 Sistem KRS Sederhana</h2>
<hr>

<nav>
  <a href="mahasiswa/index.php">Data Mahasiswa</a> |
  <a href="matakuliah/index.php">Data Mata Kuliah</a> |
  <a href="krs/index.php">Data KRS</a>
</nav>

<hr>

<h3>Selamat Datang!</h3>
<p>Aplikasi ini digunakan untuk mengelola:</p>
<ul>
  <li>Data Mahasiswa</li>
  <li>Data Mata Kuliah</li>
  <li>Kartu Rencana Studi (KRS)</li>
</ul>

<hr>
<small>&copy; <?= date('Y') ?> - Sistem KRS</small>

</body>
</html>