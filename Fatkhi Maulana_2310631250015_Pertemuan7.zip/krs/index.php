<?php
include '../koneksi.php';

$query = "SELECT KRS.*, 
                 mahasiswa.Nama AS nama_mhs, 
                 matakuliah.Nama AS nama_mk, 
                 matakuliah.Jumlah_SKS 
          FROM KRS 
          JOIN Mahasiswa ON krs.mahasiswa_NPM = mahasiswa.NPM
          JOIN Matakuliah ON krs.matakuliah_KodeMK = matakuliah.KODE_MK";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Kuliah</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #eef2f3;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            padding: 20px;
            color: #2c3e50;
        }
        .menu {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            padding: 30px;
        }
        .menu a {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            font-size: 18px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background 0.3s, transform 0.3s;
        }
        .menu a:hover {
            background-color: #2980b9;
            transform: translateY(-3px);
        }
    </style>
</head>

<h2>Data KRS</h2>
<a href="create.php">+ Tambah KRS</a>
<table border="1" cellpadding="8">
  <tr>
    <th>No</th>
    <th>Nama Lengkap</th>
    <th>Mata Kuliah</th>
    <th>Keterangan</th>
    <th>Aksi</th>
  </tr>
  <?php $no = 1; while($row = mysqli_fetch_assoc($result)) { ?>
  <tr>
    <td><?= $no++ ?></td>
    <td><?= $row['nama_mhs'] ?></td>
    <td><?= $row['nama_mk'] ?></td>
    <td><?= $row['nama_mhs'] ?> Mengambil Mata Kuliah <?= $row['nama_mk'] ?> (<?= $row['Jumlah_SKS'] ?> SKS)</td>
    <td>
      <a href="edit.php?id=<?= $row['ID'] ?>">Edit</a> |
      <a href="delete.php?id=<?= $row['ID'] ?>" onclick="return confirm('Yakin?')">Hapus</a>
    </td>
  </tr>
  <?php } ?>
</table>